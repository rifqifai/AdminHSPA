AdminHSPA is a series of admin panel dashboard pages supported by the Twitter Bootstrap UI framework and integrated directly with the JQuery plugin. The ease of using this template is my priority, because the template concept is made as simple as possible so it can be customized further.

With this template is expected to facilitate the build and can also be implemented on projects that you manage such as Project Management System, CRM, HRMS, Real Estate, Ecommerce, Loan Management System, Billing Management System, and many more

Features:
    Bootstrap
    UI components
    Analytics page (chart area, line chart, bar chart, & donut chart)
    Support glyphicon
    Editor support
    Modal components
    Blog pages
    Blog post
    List of users
    Supports Smarty version of template engine
    Developers friendly code
    And much more ...

Include Pages:
    Dashboard
    Pages
    Posts
    Users
    Analytics
    Edit
    Login
    404 Error

Download Free Template Code:
HTML version | Version of Smarty Template Engine & MySQL >> http://www.rifqifai.com/