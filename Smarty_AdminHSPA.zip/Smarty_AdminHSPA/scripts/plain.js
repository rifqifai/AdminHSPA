var ad_search = "off";
var TimerDelay = null;
var showPopupDelay = null;
var hidePopupDelay = null;
var showImageDelay = null;
var hideImageDelay = null;
var image_pop = true;
var delay = 200;

userAgent = navigator.userAgent;

var RecaptchaOptions = {
   custom_translations : {
			instructions_visual : "Ketikkan kedua kata di atas:",
      instructions_audio : "Ketikkan yang Anda dengar:",
      play_again : "Putar kembali",
      cant_hear_this : "Download suara sebagai MP3",
      visual_challenge : "Gunakan tampilan visual",
      audio_challenge : "Gunakan suara",
      refresh_btn : "Coba teks yang lain",
      help_btn : "Bantuan",
      incorrect_try_again : "Teks tidak sesuai. Coba lagi!",
   }
};

function stripHTML(arguments){
	arguments = arguments.replace(new RegExp("(<([^>]+)>)", "g"), "");
	return arguments;
}

function isIE() {
	return /msie/i.test(navigator.userAgent) && !/opera/i.test(navigator.userAgent);
}

function findParent(element, parent) {
    if (!element.is(parent))
        element = element.parents(parent);
    return element;
}

$(document).ready(function(){

	if (thisPage == "admin_page") {
		$('#adminMenu').accordion({
			navigation: true
		});
	}

}).click(function(event) {

}).mouseover(function(event) {

}).mouseout(function(event) {

}).keyup(function(event){

}).keypress(function(event){

});