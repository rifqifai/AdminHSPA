<?php
require_once('../includes/require.php');

$this_page = "posts_page";


$result = $dg->getAllposts();

require_once('../includes/global.php');
require_once('../includes/links.php');

$smarty->assign('result', $result);
$smarty->assign('this_page', $this_page);
$smarty->displayTheme('admin/posts.htm');

?>
