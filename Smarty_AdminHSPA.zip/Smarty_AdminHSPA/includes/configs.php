<?php

/* local */
$domain = $_SERVER['SERVER_NAME'];
define('BASE_URL', 'http://'.$domain.'/Smarty_AdminHSPA');

define('HOME_DIR', 'C:/xampp/htdocs/Smarty_AdminHSPA');
define('SMARTY_DIR', 'C:/xampp/Smarty/');
define('TEMPLATE_DIR', 'C:/xampp/htdocs/Smarty_AdminHSPA/templates/');
define('COMPILE_DIR', 'C:/xampp/smartytemp/Smarty_AdminHSPA/templates_c/');
define('CONFIG_DIR', 'C:/xampp/htdocs/Smarty_AdminHSPA/configs/');
define('CACHE_DIR', 'C:/xampp/smartytemp/Smarty_AdminHSPA/cache/');
define('IMAGE_DIR', 'C:/xampp/htdocs/Smarty_AdminHSPA/images/');

define('DATABASE_SERVER', 'localhost');
define('DATABASE_USERNAME', 'root');
define('DATABASE_PASSWORD', '');
define('DATABASE_NAME', 'adminhspa_db');

define('DEFAULT_LANGUAGE', 'id');
define('DEFAULT_THEME', 'plain');

define('ADMIN_MAIL', 'rifqifai@gmail.com');

define('AUTHOR', 'Rifqi Fauzi Rahmadzani');
define('DESC_SEARCH', 'rifqifai / rifqi / rifqi fauzi r / bisnis untuk|di wilayah Surakarta / Solo Raya.');
define('KEYWORDS_ADD', 'surakarta solo, solo jawa tengah, solo surakarta');

define('PAGE_SIZE', 10);

?>
