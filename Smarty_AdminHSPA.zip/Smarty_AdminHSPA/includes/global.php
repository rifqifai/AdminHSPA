<?php

$meta = $dg->getMeta($this_page, $par);

//$result = $db->getResult();

$cp_year = date('Y');

$smarty->assign('meta', $meta);
$smarty->assign('cp_year', $cp_year);
$smarty->assign('base_url', BASE_URL);
$smarty->assign('author', AUTHOR);
//$smarty->assign('result', $result);

?>