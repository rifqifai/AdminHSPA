<?php

require_once('Smarty_Site.class.php');
require_once('configs.php');

class DB_General {
    
	//var $version;
	var $link;
	var $error;

	function DB_General($link, $language = '') {
		global $languages;
		
		if ($language != '')
			$this->language = $language;
		else
			$this->language = DEFAULT_LANGUAGE;

		//$this->books = "{$languages[$versions[$this->version]['lang']]['prefix']}_books";
		
		$this->link = $link;
		
		if (mysql_select_db(DATABASE_NAME, $this->link))
			$this->error = '';
		else
			$this->error = 'Could not select database: ';
  }
	
	function JSParsing($input) {
      if (!is_array($input))
          return '"' . str_replace(array('"', "\n", "\r"),array('\"', "\\n", "\\r"),$input) . '"';
          $temp = array();
      foreach ($input as $key => $value)
          $temp[] = '"' . $key . '":' . $this->JSParsing($value);
      return "{" . implode(",",$temp) . "}";
  }
	
	function getMeta($page, $par = array()) {
		if (!$par) {
			if ($result = mysql_query("SELECT description_id, keywords_id FROM gen_page WHERE page = '{$page}';", $this->link))  {
				$row = mysql_fetch_assoc($result);
				$ret['description'] = $row['description_id'];
				$ret['keywords'] = $row['keywords_id'];
			}
			else
					$this->error = 'Invalid query: ';
		} else {
			if ($page == "business_page") {
				$l2 = str_replace("-", " ", $par['l2']); $l1 = str_replace("-", " ", $par['l1']); $c = $par['c']; 
				if ($c) {
					if ($result = mysql_query("SELECT description, keywords FROM bus_corporate WHERE LOWER(link) = '{$c}';", $this->link))  {
						$row = mysql_fetch_assoc($result);
						$ret = $row;
					}
				} else if ($l2) {
					if ($result = mysql_query("SELECT description, keywords FROM bus_l2 WHERE LOWER(level2) = '{$l2}';", $this->link))  {
						$row = mysql_fetch_assoc($result);
						$ret = $row;
					}
				} else if ($l1) {
					if ($result = mysql_query("SELECT description, keywords FROM bus_l1 WHERE LOWER(level1) = '{$l1}';", $this->link))  {
						$row = mysql_fetch_assoc($result);
						$ret = $row;
					}
				}
			} else if ($page == "search_page") {
				$desc_search = explode("|", DESC_SEARCH);
				$ret['description'] = $desc_search[0] . " " . $par['s'] . " " . $desc_search[1]; 
				$ret['keywords'] = $par['s']; 
			}
		}
		
		if ($ret['keywords'])
			$ret['keywords'] .= ", " . KEYWORDS_ADD;
		else
			$ret['keywords'] = KEYWORDS_ADD;
			
		$ret['description'] = preg_replace("/\s+/", " ", strip_tags(str_replace("<", " <", $ret['description'])));
		$ret['keywords'] = strip_tags($ret['keywords']);
			
		return $ret;
	}
	
	function antiInjection($data){
	  $filter_sql = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data, ENT_QUOTES))));
	  return $filter_sql;
	}
	
	
	function getAllusers() {
		// var_dump("SELECT * FROM users ORDER BY id_user;");
		if ($result = mysql_query("SELECT * FROM users ORDER BY id;", $this->link)) {
			$j=1;
			while ($row = mysql_fetch_assoc($result)) {
				$users_id = $row['id'];
				$ret['content'][$users_id] = $row;
				$ret['content'][$users_id]['joined'] = $this->indonesian_date($row['joined']);

			}
		}
		else{
			$this->error = 'Invalid query: ';
		}
		return $ret;
	}

	function getAllpages() {
		// var_dump("SELECT * FROM users ORDER BY id_user;");
		if ($result = mysql_query("SELECT * FROM pages ORDER BY id;", $this->link)) {
			$j=1;
			while ($row = mysql_fetch_assoc($result)) {
				$pages_id = $row['id'];
				$ret['content'][$pages_id] = $row;
				$ret['content'][$pages_id]['created'] = $this->indonesian_date($row['created']);
			}
		}
		else{
			$this->error = 'Invalid query: ';
		}
		return $ret;
	}

	function getAllposts() {
		// var_dump("SELECT * FROM users ORDER BY id_user;");
		if ($result = mysql_query("SELECT * FROM posts ORDER BY id;", $this->link)) {
			$j=1;
			while ($row = mysql_fetch_assoc($result)) {
				$posts_id = $row['id'];
				$ret['content'][$posts_id] = $row;
				$ret['content'][$posts_id]['created'] = $this->indonesian_date($row['created']);
			}
		}
		else{
			$this->error = 'Invalid query: ';
		}
		return $ret;
	}

	function indonesian_date ($timestamp = '', $date_format = 'l, j F Y') {
	    if (trim ($timestamp) == '')
	    {
	            $timestamp = time ();
	    }
	    elseif (!ctype_digit ($timestamp))
	    {
	        $timestamp = strtotime ($timestamp);
	    }
	    # remove S (st,nd,rd,th) there are no such things in indonesia :p
	    $date_format = preg_replace ("/S/", "", $date_format);
	    $pattern = array (
	        '/Mon[^day]/','/Tue[^sday]/','/Wed[^nesday]/','/Thu[^rsday]/',
	        '/Fri[^day]/','/Sat[^urday]/','/Sun[^day]/','/Monday/','/Tuesday/',
	        '/Wednesday/','/Thursday/','/Friday/','/Saturday/','/Sunday/',
	        '/Jan[^uary]/','/Feb[^ruary]/','/Mar[^ch]/','/Apr[^il]/','/May/',
	        '/Jun[^e]/','/Jul[^y]/','/Aug[^ust]/','/Sep[^tember]/','/Oct[^ober]/',
	        '/Nov[^ember]/','/Dec[^ember]/','/January/','/February/','/March/',
	        '/April/','/June/','/July/','/August/','/September/','/October/',
	        '/November/','/December/',
	    );
	    $replace = array ( 'Sen','Sel','Rab','Kam','Jum','Sab','Min',
	        'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu',
	        'Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des',
	        'Januari','Februari','Maret','April','Juni','Juli','Agustus','Sepember',
	        'Oktober','November','Desember',
	    );
	    $date = date ($date_format, $timestamp);
	    $date = preg_replace ($pattern, $replace, $date);
	    $date = "{$date}";
	    return $date;
} 

}
?>