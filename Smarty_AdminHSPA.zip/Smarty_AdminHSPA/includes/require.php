<?php
//error_reporting(0);
require_once('Smarty_Site.class.php');
require_once('DB_General.class.php');

$smarty = new Smarty_Site();
$dg = new DB_General($smarty->link1, $smarty->lang);

?>