<?php
$cookie_path = "/";
$cookie_timeout = 2592000; //60 * 60 *24 *30; // in seconds
session_set_cookie_params($cookie_timeout, $cookie_path);
session_start();
header("Cache-control: private");

require_once('configs.php');
require(SMARTY_DIR . 'Smarty.class.php');

class Smarty_Site extends Smarty {

	var $lang = '';
	var $theme = '';
	var $version = '';
	var $version_language = '';
	var	$content_type = '';
	var $home_page = '';
	
	var $bookmap = array();
	var $reversemap = array();
	var $booknames = '';

    var $link1;
    var $link2;
    var $link3;

	function Smarty_Site() {
		$this->Smarty();
		$this->template_dir = TEMPLATE_DIR;
		$this->compile_dir = COMPILE_DIR;
		$this->config_dir = CONFIG_DIR;
		$this->cache_dir = CACHE_DIR;
//		$this->caching = false;
		$this->setVersion($_GET['version']);
		$this->setLanguage($_GET['lang']);
		$this->setTheme($_GET['theme']);
		$this->register_function('create_url', array('Smarty_Site', 'createURL'));
		$this->register_function('capitalize_words', array('Smarty_Site', 'capitalizeWords'));
		
		if ($link = mysql_connect(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD, true)) {
		    mysql_query("SET NAMES 'utf8'", $link);
		    $this->link1 = $link;
		}
		else
		    die("Can not connect to database. Please hit refresh to try again.");
	}
	
	function setVersion($version) {
	    global $versions;
	    if ($version != '') {
            $this->version = $version;
            $_SESSION['version'] = $version;
        }                                            
        elseif (isset($_SESSION['version']))
            $this->version = $_SESSION['version'];
        else                                         
            $this->version = DEFAULT_VERSION;
        $this->assign('version', $this->version);
        $this->assign('version_language', $versions[$this->version]['lang']);
	}

	function setLanguage($lang) {
		if ($lang != '') {
            $this->lang = $lang;
            $_SESSION['lang'] = $lang;
        }                                            
        elseif (isset($_SESSION['lang']))
            $this->lang = $_SESSION['lang'];
        else                                         
            $this->lang = DEFAULT_LANGUAGE;
		if ($this->lang != '')
		    $this->loadLanguage($this->lang . '/');

		$this->assign('lang', $this->lang);
	}

	function loadLanguage($dir) {
		if (is_dir(CONFIG_DIR . $dir)) {
			if ($dh = opendir(CONFIG_DIR . $dir)) {
				while (($file = readdir($dh)) !== false) {
					if (is_file(CONFIG_DIR . $dir . $file))
						$this->config_load($dir . $file);
					elseif (($file != '.') && ($file != '..') && (is_dir(CONFIG_DIR . $dir . $file)))
						$this->loadLanguage($dir . $file);
				}
			}
		}
	}

	function setTheme($theme) {
		if ($theme != DEFAULT_THEME)
			$this->theme = $theme;
//		if ($this->theme != '')
//			$this->assign('template_path', 'templates' . '/' . $this->theme . '/');
//		else
//			$this->assign('template_path', 'templates' . '/' . DEFAULT_THEME . '/');
		$this->assign('theme', $this->theme);
	}

    function setContentType($content_type) {
        $this->content_type = $content_type;
    }

	function displayTheme($template) {
		if (is_file(TEMPLATE_DIR . $this->theme . '/' . $template)) {
			$template = $this->theme . '/' . $template;
		}
		elseif (is_file(TEMPLATE_DIR . DEFAULT_THEME . '/' . $template)) {
			$template = DEFAULT_THEME . '/' . $template;
		}
		$this->display($template);
	}

	function createURL($params) {
		$par = array();
		foreach ($params as $key => $value) {
			if ($key == "base")
				$page = $value;
			elseif ($key == "anchor")
				$anchor = $value;
			elseif ($key == "l1")
				$l1 = $value;
			elseif ($key == "l2")
				$l2 = $value;	
			elseif ($key == "c")
				$c = $value;
			elseif ($key == "s")
				$s = $value;		
			elseif ($key == "p")
				$p = $value;	
			elseif ($key == "o")
				$o = $value;		
			elseif ($key == "cid")
				$cid = $value;			
			elseif ($value != '')
				$par[] = "$key=$value";
		}
		
		$pa = implode('&amp;', $par);
		
		if ($l1 && $l2 && $p && $o)
			$page = "$page/$l1/$l2/$p/$o";
		elseif ($l1 && $p && $o)
			$page = "$page/$l1/$p/$o";	
		elseif ($l1 && $l2 && $p)
			$page = "$page/$l1/$l2/$p";
		elseif ($l1 && $p)
			$page = "$page/$l1/$p";	
		elseif ($l1 && $l2)
			$page = "$page/$l1/$l2";
		elseif ($l1)
			$page = "$page/$l1";
		elseif ($c)
			$page = "$page/$c";
		elseif ($p && $cid)
			$page = "$page/$p/$cid";	
		elseif ($o && $s && $p)
			$page = "$page/$s/$p/$o";
		elseif ($s && $p)
			$page = "$page/$s/$p";
		elseif ($s)
			$page = "$page/$s";
		elseif ($p)
			$page = "$page/$p";
		if ($pa != '')
			$page .= "?$pa";
		if ($anchor != '')
			$page .= "#$anchor";
		return str_replace(" ", "+", $page);
	}
	
/*
	function createURL($params) {
		$par = array();
		foreach ($params as $key => $value) {
			if ($key == "base")
				$page = $value;
			elseif ($key == "anchor")
				$anchor = $value;
			elseif ($value != '')
				$par[] = "$key=$value";
		}
		//if ($this->lang != '')
		//	$par[] = "lang={$this->lang}";
		if ($this->theme != '')
			$par[] = "theme={$this->theme}";
		$p = implode('&amp;', $par);
		if ($p != '')
			$page = "$page?$p";
		if ($anchor != '')
			$page = "$page#$anchor";
		return $page;
	}	
*/	
	
	function capitalizeWords($params) {
		$text = $params['text'];
		$text = str_replace("_", " ", $text);
		$text = ucwords($text);
		return $text;
	}
}

?>
