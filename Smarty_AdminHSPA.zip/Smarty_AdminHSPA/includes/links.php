<?php

// internal

$base_url = BASE_URL;
$another_page = BASE_URL . '/another';
$admin_page = BASE_URL . '/admin';
$admin_pages_page = BASE_URL . '/admin/pages';
$admin_posts_page = BASE_URL . '/admin/posts';
$admin_users_page = BASE_URL . '/admin/users';
$admin_analytics_page = BASE_URL . '/admin/analytics';
$admin_edit_page = BASE_URL . '/admin/edit';
$admin_404_page = BASE_URL . '/admin/404';
$admin_login_page = BASE_URL . '/admin/login';

$smarty->assign('base_url', BASE_URL);
$smarty->assign('home_page', BASE_URL);
$smarty->assign('admin_page', $admin_page);
$smarty->assign('admin_pages_page', $admin_pages_page);
$smarty->assign('admin_posts_page', $admin_posts_page);
$smarty->assign('admin_users_page', $admin_users_page);
$smarty->assign('admin_analytics_page', $admin_analytics_page);
$smarty->assign('admin_edit_page', $admin_edit_page);
$smarty->assign('admin_404_page', $admin_404_page);
$smarty->assign('admin_login_page', $admin_login_page);
// external

$smarty->assign('website', 'http://www.rifqifai.com/');
$smarty->assign('facebook', 'http://www.facebook.com/rifqifai');
$smarty->assign('twitter', 'http://www.twitter.com/rifqifai');

?>
