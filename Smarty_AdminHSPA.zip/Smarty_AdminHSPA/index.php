<?php

require_once('includes/require.php');

$this_page = "home_page";

require_once('includes/global.php');
require_once('includes/links.php');

$smarty->assign('this_page', $this_page);
$smarty->displayTheme('index.htm');

?>
