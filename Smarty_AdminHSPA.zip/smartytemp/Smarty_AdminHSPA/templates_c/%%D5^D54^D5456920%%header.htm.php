<?php /* Smarty version 2.6.25, created on 2017-04-20 19:25:36
         compiled from plain/admin/header.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'create_url', 'plain/admin/header.htm', 39, false),)), $this); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $this->_tpl_vars['title']; ?>
</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $this->_tpl_vars['base_url']; ?>
/styles/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $this->_tpl_vars['base_url']; ?>
/styles/style.css" rel="stylesheet">

    <!-- Ckeditor script source -->
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/ckeditor/ckeditor.js"></script>

    <!-- Morris Chart -->
    <link rel="stylesheet" href="<?php echo $this->_tpl_vars['base_url']; ?>
/styles/morris.css">
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/jquery-3.2.0.min.js"></script>
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/raphael-min.js"></script>
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/morris.min.js"></script>

  </head>
  <body>

    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">AdminHSPA</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li <?php if ($this->_tpl_vars['this_page'] == 'admin_page'): ?> class="active" <?php endif; ?>><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
">Dashboard</a></li>
            <li <?php if ($this->_tpl_vars['this_page'] == 'pages_page'): ?> class="active" <?php endif; ?>><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_pages_page']), $this);?>
">Pages</a></li>
            <li <?php if ($this->_tpl_vars['this_page'] == 'posts_page'): ?> class="active" <?php endif; ?>><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_posts_page']), $this);?>
">Posts</a></li>
            <li <?php if ($this->_tpl_vars['this_page'] == 'users_page'): ?> class="active" <?php endif; ?>><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_users_page']), $this);?>
">Users</a></li>
            <li <?php if ($this->_tpl_vars['this_page'] == 'analytics_page'): ?> class="active" <?php endif; ?>><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_analytics_page']), $this);?>
">Analytics</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#">Welcome, Rifqifai <span class="glyphicon glyphicon-user"></span></a></li>
            <li><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_login_page']), $this);?>
">Logout <span class="glyphicon glyphicon-log-out"></a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1><span class="glyphicon glyphicon-fire" aria-hidden="true"></span> Dashboard <small>Manage Your Site</small></h1>
          </div>
          <div class="col-md-2">
            <div class="dropdown create">
              <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Create Content
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li><a type="button" data-toggle="modal" data-target="#addPage">Add Page</a></li>
                <li><a href="#">Add Post</a></li>
                <li><a href="#">Add User</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>

    <section id="breadcrumb">
      <div class="container">
        <ol class="breadcrumb">
          <?php if ($this->_tpl_vars['this_page'] == 'admin_page'): ?><li class="active">Dashboard</li><?php endif; ?>
          <?php if ($this->_tpl_vars['this_page'] == 'pages_page'): ?><li><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
">Dashboard</a></li><li class="active">Pages</li><?php endif; ?>
          <?php if ($this->_tpl_vars['this_page'] == 'posts_page'): ?><li><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
">Dashboard</a></li><li class="active">Posts</li><?php endif; ?>
          <?php if ($this->_tpl_vars['this_page'] == 'users_page'): ?><li><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
">Dashboard</a></li><li class="active">Users</li><?php endif; ?>
          <?php if ($this->_tpl_vars['this_page'] == 'analytics_page'): ?><li><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
">Dashboard</a></li><li class="active">Analytics</li><?php endif; ?>
          <?php if ($this->_tpl_vars['this_page'] == 'edit_page'): ?><li><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
">Dashboard</a></li><li><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_pages_page']), $this);?>
">Pages</a></li><li class="active">Edit</li><?php endif; ?>
          <?php if ($this->_tpl_vars['this_page'] == '404_page'): ?><li><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
">Dashboard</a></li><li class="active">404 Error</li><?php endif; ?>
        </ol>
      </div>
    </section>

    <!-- Add Page -->
    <div class="modal fade" id="addPage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form>
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Add Page</h4>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>Page Title</label>
              <input type="text" class="form-control" placeholder="Page Title">
            </div>
            <div class="form-group">
              <label>Page Body</label>
              <textarea name="editor1" class="form-control" placeholder="Page Body"></textarea>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox"> Published
              </label>
            </div>
            <div class="form-group">
              <label>Meta Tag</label>
              <input type="text" class="form-control" placeholder="Add Some Tags...">
            </div>
            <div class="form-group">
              <label>Meta Description</label>
              <input type="text" class="form-control" placeholder="Add Meta Description...">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
          </div>
        </form>
        </div>
      </div>
    </div>