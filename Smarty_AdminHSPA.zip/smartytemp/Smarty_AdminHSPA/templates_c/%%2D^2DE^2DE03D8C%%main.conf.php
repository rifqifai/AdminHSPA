<?php $_config_vars = array (
  'sitename' => 'AdminHSPA | Dashboard',
  'domain' => 'www.rifqifai.com',
  'cp' => '&copy',
  'privacy_policy' => 'Privacy Policy',
  'terms_of_use' => 'Terms Of Use',
  'home' => 'Home',
  'contact_us' => 'Hubungi Kami',
  'login' => 'Login',
  'logout' => 'Keluar',
); ?>