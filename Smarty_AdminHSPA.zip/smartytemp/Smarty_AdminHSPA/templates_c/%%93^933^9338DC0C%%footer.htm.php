<?php /* Smarty version 2.6.25, created on 2017-04-10 22:28:32
         compiled from plain/footer.htm */ ?>
 <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/startbootstrap/vendor/jquery/jquery.min.js"></script>
<!-- Bootstrap Core JavaScript -->
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/startbootstrap/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/startbootstrap/vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/startbootstrap/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/startbootstrap/js/creative.min.js"></script>
    <script language="JavaScript" type="text/javascript">
<!--
thisPage = "<?php echo $this->_tpl_vars['this_page']; ?>
";
baseUrl = "<?php echo $this->_tpl_vars['base_url']; ?>
";
-->
</script>
</body>
</html>