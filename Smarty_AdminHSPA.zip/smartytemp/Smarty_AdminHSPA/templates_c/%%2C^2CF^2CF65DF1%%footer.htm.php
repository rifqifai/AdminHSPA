<?php /* Smarty version 2.6.25, created on 2017-04-19 22:26:45
         compiled from plain/admin/footer.htm */ ?>
          </div>
        </div>
      </div>
    </section>

    <footer class="footer">
      <p>2017 &copy; Copyright <a href="http://rifqifai.com">Rifqifai</a></p>
    </footer>

    <!-- Modals -->

    <script>
      CKEDITOR.replace( 'editor1' );
    </script>
    
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/chart.js"></script>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/jquery-3.2.0.min.js"></script>
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/bootstrap.min.js"></script>
  </body>
</html>