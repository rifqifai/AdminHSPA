<?php /* Smarty version 2.6.25, created on 2017-04-20 19:25:36
         compiled from plain/admin/sidebar.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'create_url', 'plain/admin/sidebar.htm', 6, false),)), $this); ?>
    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="list-group">
              <a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
" class="list-group-item active main-color-bg">
                <span class="glyphicon glyphicon-fire" aria-hidden="true"></span> Dashboard
              </a>
              <a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_pages_page']), $this);?>
" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Pages <span class="badge">12</span></a>
              <a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_posts_page']), $this);?>
" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Posts <span class="badge">33</span></a>
              <a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_users_page']), $this);?>
" class="list-group-item"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Users <span class="badge">5</span></a>
              <a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_analytics_page']), $this);?>
" class="list-group-item"><span class="glyphicon glyphicon glyphicon-stats" aria-hidden="true"></span> Analytics <span class="badge">12,334</span></a>
              <a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_404_page']), $this);?>
" class="list-group-item"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> 404 Error</a>
            </div>

            <div class="well">
            <h4>Disk Space Used</h4>
              <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
                  60%
                </div>
              </div>
            <h4>Bandwith Used</h4>
              <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%;">
                  40%
                </div>
              </div>
            <h4>Email Account (5/25)</h4>
              <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 20%;">
                  5
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-9">
          