<?php /* Smarty version 2.6.25, created on 2017-04-19 22:05:22
         compiled from plain/users/edit.htm */ ?>
<?php ob_start(); ?>
    Admin Area | Edit
<?php $this->_smarty_vars['capture']['title'] = ob_get_contents(); ob_end_clean(); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/users/header.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/users/sidebar.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
          <!-- Website Overview -->
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">Edit Pages</h3>
              </div>
              <div class="panel-body">
                <form>
                  <div class="form-group">
                    <label>Page Title</label>
                    <input type="text" class="form-control" placeholder="Page Title" value="About">
                  </div>
                  <div class="form-group">
                    <label>Page Body</label>
                    <textarea name="editor2" class="form-control" placeholder="Page Body">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla ducimus sequi, natus beatae dolor obcaecati. Dolor, totam inventore reprehenderit ad a eum explicabo est autem nesciunt doloribus optio, suscipit dicta.
                    </textarea>
                  </div>
                  <div class="checkbox">
                    <label>
                      <input type="checkbox" checked> Published
                    </label>
                  </div>
                  <div class="form-group">
                    <label>Meta Tag</label>
                    <input type="text" class="form-control" placeholder="Add Some Tags..." value="tag1, tag2">
                  </div>
                  <div class="form-group">
                    <label>Meta Description</label>
                    <input type="text" class="form-control" placeholder="Add Meta Description..." value="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates sapiente ipsam quas voluptas neque, alias molestias blanditiis debitis facere officiis quaerat iure similique deserunt assumenda labore aperiam ut asperiores minus. ">
                  </div>
                  <input type="submit" class="btn btn-default" value="Submit">
                </form>
              </div>
            </div>
    <script>
      CKEDITOR.replace( 'editor2' );
    </script>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/users/footer.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>