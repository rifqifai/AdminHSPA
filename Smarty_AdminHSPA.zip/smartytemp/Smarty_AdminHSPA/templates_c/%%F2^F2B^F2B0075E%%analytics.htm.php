<?php /* Smarty version 2.6.25, created on 2017-04-19 22:37:47
         compiled from plain/admin/analytics.htm */ ?>
<?php ob_start(); ?>
    Admin Area | Analytics
<?php $this->_smarty_vars['capture']['title'] = ob_get_contents(); ob_end_clean(); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/admin/header.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/admin/sidebar.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
          <!-- Area Chart -->
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">Area Chart</h3>
              </div>
              <div class="panel-body">
                <div class="col-md-12">
                  <div id="area-example"></div>
                </div>
              </div>
            </div>

            <!-- Line Chart -->
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">Line Chart</h3>
              </div>
              <div class="panel-body">
                <div class="col-md-12">
                  <div id="line-example"></div>
                </div>
              </div>
            </div>

            <!-- Bar Chart -->
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">Bar Chart</h3>
              </div>
              <div class="panel-body">
                <div class="col-md-12">
                  <div id="bar-example"></div>
                </div>
              </div>
            </div>

            <!-- Donut Chart -->
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">Donut Chart</h3>
              </div>
              <div class="panel-body">
                <div class="col-md-4">
                  <div id="donut-example1"></div>
                </div>
                <div class="col-md-4">
                  <div id="donut-example2"></div>
                </div>
                <div class="col-md-4">
                  <div id="donut-example3"></div>
                </div>
              </div>
            </div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/admin/footer.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>