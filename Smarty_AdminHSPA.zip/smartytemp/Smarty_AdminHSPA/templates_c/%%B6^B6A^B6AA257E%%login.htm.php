<?php /* Smarty version 2.6.25, created on 2017-04-19 21:14:48
         compiled from plain/users/login.htm */ ?>
<?php ob_start(); ?>
    Admin Area | Account Login
<?php $this->_smarty_vars['capture']['title'] = ob_get_contents(); ob_end_clean(); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $this->_tpl_vars['title']; ?>
</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $this->_tpl_vars['base_url']; ?>
/styles/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $this->_tpl_vars['base_url']; ?>
/styles/style.css" rel="stylesheet">

  </head>
  <body>

    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Rifqifai Blog</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1 class="text-center">Admin Area <small>Account Login</small></h1>
          </div>
        </div>
      </div>
    </header>

    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4">
          <form action="index.html" class="well" id="login">
            <div class="form-group">
              <label>Email Address</label>
              <input type="text" class="form-control" placeholder="Enter Your Email">
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" class="form-control" placeholder="Enter Your Password">
            </div>
            <button type="submit" class="btn btn-default btn-block">Login</button>
            <br>
            <p class="text-center"><a href="#">Forgot Your Password</a></p>
          </form>
          </div>
        </div>
      </div>
    </section>

    <footer class="footer" id="login-footer">
      <p>2017 &copy; Copyright <a href="http://rifqifai.com">Rifqifai</a></p>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/jquery-3.2.0.min.js"></script>
    <script src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/bootstrap.min.js"></script>
  </body>
</html>