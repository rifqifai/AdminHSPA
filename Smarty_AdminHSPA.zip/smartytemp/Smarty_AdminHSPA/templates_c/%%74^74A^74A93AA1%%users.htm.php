<?php /* Smarty version 2.6.25, created on 2017-04-20 19:26:23
         compiled from plain/admin/users.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'create_url', 'plain/admin/users.htm', 31, false),)), $this); ?>
<?php ob_start(); ?>
    Admin Area | Users
<?php $this->_smarty_vars['capture']['title'] = ob_get_contents(); ob_end_clean(); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/admin/header.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/admin/sidebar.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>  
          <!-- Users Table -->
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">Users</h3>
              </div>
              <div class="panel-body">
                <div class="row">
                  <div class="col-md-12">
                    <input type="text" class="form-control" placeholder="Filter Users...">
                  </div>
                </div>
                <br>
                <table class="table table-striped table-hover">
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Joined</th>
                    <th></th>
                  </tr>
                  <tr>
                  <?php $_from = $this->_tpl_vars['result']['content']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['users']):
?>
                  <tr>
                    <td><?php echo $this->_tpl_vars['users']['name']; ?>
</td>
                    <td><?php echo $this->_tpl_vars['users']['email']; ?>
</td>
                    <td><?php echo $this->_tpl_vars['users']['joined']; ?>
</td>
                    <td><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_edit_page']), $this);?>
" class="btn btn-default">Edit</a> <a href="#" class="btn btn-danger">Delete</a></td>
                  </tr>
                  <?php endforeach; endif; unset($_from); ?>            
                </table>
              </div>
            </div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/admin/footer.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>