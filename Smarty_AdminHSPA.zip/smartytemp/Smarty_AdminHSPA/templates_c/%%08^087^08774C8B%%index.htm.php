<?php /* Smarty version 2.6.25, created on 2017-04-20 20:30:46
         compiled from plain/index.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'create_url', 'plain/index.htm', 6, false),)), $this); ?>
<?php ob_start(); ?>
    <?php echo $this->_config[0]['vars']['sitename']; ?>

<?php $this->_smarty_vars['capture']['title'] = ob_get_contents(); ob_end_clean(); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/header.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<div>
	<center><h3>Visit admin panel on this link >> <a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
">AdminHSPA | Panel Dashboard</a></h3></center>
	</div>
<script language="JavaScript" type="text/javascript">
<!--
page = "<?php echo $this->_tpl_vars['this_page']; ?>
";
-->
</script>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/footer.htm", 'smarty_include_vars' => array('this_page' => $this->_tpl_vars['this_page'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>