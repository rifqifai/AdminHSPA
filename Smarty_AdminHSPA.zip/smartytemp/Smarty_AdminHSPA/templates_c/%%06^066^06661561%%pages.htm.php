<?php /* Smarty version 2.6.25, created on 2017-04-19 22:10:51
         compiled from plain/users/pages.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'create_url', 'plain/users/pages.htm', 29, false),)), $this); ?>
<?php ob_start(); ?>
    Admin Area | Pages
<?php $this->_smarty_vars['capture']['title'] = ob_get_contents(); ob_end_clean(); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/users/header.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/users/sidebar.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
          <!-- Website Overview -->
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">Pages</h3>
              </div>
              <div class="panel-body">
                <div class="row">
                  <div class="col-md-12">
                    <input type="text" class="form-control" placeholder="Filter Pages...">
                  </div>
                </div>
                <br>
                <table class="table table-striped table-hover">
                  <tr>
                    <th>Title</th>
                    <th>Published</th>
                    <th>Created</th>
                    <th></th>
                  </tr>
                  <tr>
                    <td>Home</td>
                    <td><span class="glyphicon glyphicon-ok" aria-hidden="true"></span></td>
                    <td>Dec 12, 2016</td>
                    <td><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_edit_page']), $this);?>
" class="btn btn-default">Edit</a> <a href="#" class="btn btn-danger">Delete</a></td>
                  </tr>
                  <tr>
                    <td>About</td>
                    <td><span class="glyphicon glyphicon-ok" aria-hidden="true"></span></td>
                    <td>Dec 13, 2016</td>
                    <td><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_edit_page']), $this);?>
" class="btn btn-default">Edit</a> <a href="#" class="btn btn-danger">Delete</a></td>
                  </tr>
                  <tr>
                    <td>Services</td>
                    <td><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></td>
                    <td>Dec 13, 2016</td>
                    <td><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_edit_page']), $this);?>
" class="btn btn-default">Edit</a> <a href="#" class="btn btn-danger">Delete</a></td>
                  </tr>
                  <tr>
                    <td>Contact</td>
                    <td><span class="glyphicon glyphicon-ok" aria-hidden="true"></span></td>
                    <td>Dec 14, 2016</td>
                    <td><a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_edit_page']), $this);?>
" class="btn btn-default">Edit</a> <a href="#" class="btn btn-danger">Delete</a></td>
                  </tr>
                </table>
              </div>
            </div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/users/footer.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>