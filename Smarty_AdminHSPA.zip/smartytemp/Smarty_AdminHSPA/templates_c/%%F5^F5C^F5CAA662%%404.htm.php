<?php /* Smarty version 2.6.25, created on 2017-04-20 19:32:00
         compiled from plain/admin/404.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'create_url', 'plain/admin/404.htm', 17, false),)), $this); ?>
<?php ob_start(); ?>
    Admin Area | Dashboard
<?php $this->_smarty_vars['capture']['title'] = ob_get_contents(); ob_end_clean(); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/admin/header.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/admin/sidebar.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
            <!-- 404 Content -->
              <section class="content-header">
                <h4>404 Error Page</h4>
              </section>
              <section class="content">
                <div class="error-page">
                  <h2 class="headline text-yellow"> 404</h2>
                  <div class="error-content">
                    <h3><small><span class="glyphicon glyphicon-exclamation-sign"></span></small> Oops! Page not found.</h3>
                    <p>
                      We could not find the page you were looking for.
                      Meanwhile, you may <a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['admin_page']), $this);?>
">return to dashboard</a> or try using the search form.
                    </p>
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Search for...">
                      <span class="input-group-btn">
                        <button class="btn btn-default" type="button">Go!</button>
                      </span>
                    </div>
                  </div>
                </div>
              </section>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "plain/admin/footer.htm", 'smarty_include_vars' => array('title' => $this->_smarty_vars['capture']['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>