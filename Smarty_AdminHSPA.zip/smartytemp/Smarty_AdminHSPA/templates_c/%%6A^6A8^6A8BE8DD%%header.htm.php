<?php /* Smarty version 2.6.25, created on 2017-04-19 01:35:31
         compiled from plain/header.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'create_url', 'plain/header.htm', 21, false),)), $this); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->_tpl_vars['title']; ?>
</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="" />

<link rel="stylesheet" href="<?php echo $this->_tpl_vars['base_url']; ?>
/styles/plain.css" type="text/css" />
<script type="text/javascript" language="javascript" src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/jquery-1.4.2.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo $this->_tpl_vars['base_url']; ?>
/scripts/plain.js"></script>
</head>

<body style="margin:0px;">
<div id="pageBody">
	<div class="site-wrapper">
		<div id="header">
			
			<a href="<?php echo Smarty_Site::createURL(array('base' => $this->_tpl_vars['testimonial_page']), $this);?>
"><?php echo $this->_config[0]['vars']['testimonial']; ?>
</a>
			
		</div>
		<div id="main">